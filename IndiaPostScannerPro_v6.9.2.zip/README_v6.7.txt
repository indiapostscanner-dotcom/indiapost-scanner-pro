India Post Auto Bag Open Pro v6.7
- Stable v6.4 offline persistence retained
- Original v5.2 core scanning engine restored
- Original Turbo 0ms mode restored
- No backend dependency
- Same Device ID persistence retained
