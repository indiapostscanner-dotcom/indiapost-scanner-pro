// India Post Auto Bag Open Pro v6.4 — Background
// Core injection preserved: content.js + page_world.js. Adds page_store.js for site localStorage.
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.__src === 'page') {
    chrome.runtime.sendMessage({ ...msg, __src: 'bg' }).catch(() => {});
  }

  if (msg.type === 'INJECT') {
    const tabId = msg.tabId;
    (async () => {
      try {
        await chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'], world: 'ISOLATED' });
        await chrome.scripting.executeScript({ target: { tabId }, files: ['page_store.js'], world: 'MAIN' });
        await chrome.scripting.executeScript({ target: { tabId }, files: ['page_world.js'], world: 'MAIN' });
        sendResponse({ ok: true });
      } catch (err) {
        sendResponse({ ok: false, error: err.message });
      }
    })();
    return true;
  }

  if (msg.type === 'CMD') {
    chrome.tabs.sendMessage(msg.tabId, { __toPage: true, ...msg })
      .then(() => sendResponse({ ok: true }))
      .catch(e => sendResponse({ ok: false, error: e.message }));
    return true;
  }
});
