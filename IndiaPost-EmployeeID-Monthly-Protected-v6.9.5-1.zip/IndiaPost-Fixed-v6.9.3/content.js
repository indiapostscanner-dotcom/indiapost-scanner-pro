// ============================================================
// India Post Auto Bag Open Pro — Content Script (Isolated World)
// Bridges messages between the extension popup/background and
// the page_world.js script running in MAIN world.
// Content scripts cannot access React internals — only page_world.js can.
// ============================================================

(function () {
  if (window.__IPAP_bridge) return;
  window.__IPAP_bridge = true;

  // Page world → background → popup
  window.addEventListener('IPAP_toExt', (e) => {
    chrome.runtime.sendMessage({ __src: 'page', ...e.detail }).catch(() => {});
  });

  // Background/popup → page world
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.__toPage) {
      window.dispatchEvent(new CustomEvent('IPAP_fromExt', { detail: msg }));
      sendResponse({ ok: true });
    }
    return true;
  });

  console.log('[IPAP] Bridge ready');
})();
