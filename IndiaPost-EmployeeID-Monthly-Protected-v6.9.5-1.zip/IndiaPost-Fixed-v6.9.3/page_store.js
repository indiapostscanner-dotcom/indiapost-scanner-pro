// India Post Auto Bag Open Pro v6.9.5 — Employee ID Monthly License Store (tamper-resistant)
// Scan engine is NOT here. This file only handles Employee ID, trial, licence and admin reset.
(function () {
  if (window.__IPAP_STORE_V695_EMP_PROTECTED) return;
  window.__IPAP_STORE_V695_EMP_PROTECTED = true;

  const LEGACY_KEY = 'IPAP_OFFLINE_LICENSE_STATE_V1';
  const TRIAL_DAYS = 1;
  const DAY = 24 * 60 * 60 * 1000;

  // Offline monthly licence format:
  // EMP + EmployeeID(8) + YYMMDD(6) + SIG(5) = 22 chars
  // Example: EMP1032287426061891DD4
  // Kept split to stop casual editing/searching in Sources.
  const LICENSE_SECRET = ['IPBS','INDIAPOST','2025','SECRET'].join('$');
  const STATE_SALT = ['IPAP','STATE','LOCK','V3','EMP'].join('$');
  const ADMIN_SALT = ['IPAP','ADMIN','RESET','V3'].join('$');

  function emit(detail) {
    window.dispatchEvent(new CustomEvent('IPAP_toExt', { detail }));
  }

  function cleanText(v) {
    return String(v || '').replace(/\s+/g, ' ').trim();
  }

  function getEmployeeIdFromDom() {
    const direct = Array.from(document.querySelectorAll('span.font-bold.italic'))
      .map(el => cleanText(el.textContent))
      .find(t => /^\d{8}$/.test(t));
    if (direct) return direct;

    const nodes = Array.from(document.querySelectorAll('span, div, p, td, strong, b'));
    for (const el of nodes) {
      const t = cleanText(el.textContent);
      if (/^\d{8}$/.test(t)) return t;
    }
    return null;
  }

  function getStorageKey(employeeId) {
    return 'IPAP_STATE_V3_EMP' + (employeeId || 'UNKNOWN');
  }
  function getOldStorageKey(employeeId) {
    return 'IPAP_STATE_V2_EMP' + (employeeId || 'UNKNOWN');
  }
  function getBackupKey1(employeeId) {
    return '__IPAP_BAK_A_' + btoa(String(employeeId || 'UNKNOWN')).replace(/=/g, '');
  }
  function getBackupKey2(employeeId) {
    return '__IPAP_BAK_B_' + String(employeeId || 'UNKNOWN').split('').reverse().join('');
  }
  function getTamperKey(employeeId) {
    return '__IPAP_TAMPER_LOCK_' + (employeeId || 'UNKNOWN');
  }

  function stableStateForSign(state) {
    const clone = Object.assign({}, state || {});
    delete clone.stateSig;
    return [
      clone.employeeId || '',
      clone.installTs || '',
      clone.firstSeenTs || '',
      clone.createdBy || '',
      clone.licenseKey || '',
      clone.licenseEmployeeId || '',
      clone.licenseExpiryTs || '',
      clone.licenseExpiryStr || '',
      clone.trialUsed ? '1' : '0',
      clone.trialResetCount || 0,
      clone.tamperLocked ? '1' : '0',
      STATE_SALT
    ].join('|');
  }

  async function hmacRaw(secret, message, takeChars) {
    const enc = new TextEncoder();
    const key = await crypto.subtle.importKey(
      'raw', enc.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']
    );
    const sig = await crypto.subtle.sign('HMAC', key, enc.encode(message));
    const hex = Array.from(new Uint8Array(sig))
      .map(b => b.toString(16).padStart(2, '0').toUpperCase())
      .join('');
    return takeChars ? hex.slice(0, takeChars) : hex;
  }

  async function stateSignature(state) {
    return hmacRaw(LICENSE_SECRET, stableStateForSign(state), 16);
  }

  async function signState(state) {
    state.stateSig = await stateSignature(state);
    return state;
  }

  async function isStateValid(state, employeeId) {
    if (!state || typeof state !== 'object') return false;
    if (state.employeeId !== employeeId) return false;
    if (!state.stateSig) return false;
    const expected = await stateSignature(state);
    return state.stateSig === expected;
  }

  function parseJson(raw) {
    try { return raw ? JSON.parse(raw) : null; } catch (_) { return null; }
  }

  function allStateKeys(employeeId) {
    return [getStorageKey(employeeId), getBackupKey1(employeeId), getBackupKey2(employeeId)];
  }

  async function writeState(employeeId, state) {
    state.employeeId = employeeId;
    state.deviceId = employeeId; // popup compatibility only
    state.trialUsed = true;
    state.updatedAt = Date.now();
    await signState(state);
    const raw = JSON.stringify(state);
    for (const k of allStateKeys(employeeId)) {
      try { localStorage.setItem(k, raw); } catch (_) {}
    }
  }

  async function makeTamperLockedState(employeeId, reason) {
    const now = Date.now();
    const state = {
      employeeId,
      deviceId: employeeId,
      installTs: now - (TRIAL_DAYS + 10) * DAY,
      firstSeenTs: now,
      createdBy: 'IPAP_v6.9.5_tamper_lock',
      trialUsed: true,
      tamperLocked: true,
      tamperReason: reason || 'State changed or deleted',
      trialResetCount: 0
    };
    try { localStorage.setItem(getTamperKey(employeeId), String(now)); } catch (_) {}
    await writeState(employeeId, state);
    return state;
  }

  async function readState(employeeId) {
    let best = null;
    let foundInvalid = false;

    for (const k of allStateKeys(employeeId)) {
      const parsed = parseJson(localStorage.getItem(k));
      if (!parsed) continue;
      if (await isStateValid(parsed, employeeId)) {
        if (!best || Number(parsed.installTs || 0) < Number(best.installTs || 0)) best = parsed;
      } else {
        foundInvalid = true;
      }
    }

    if (best) {
      // Restore missing/edited copies from the oldest valid signed copy.
      await writeState(employeeId, best);
      return best;
    }

    const oldRaw = localStorage.getItem(getOldStorageKey(employeeId)) || localStorage.getItem(LEGACY_KEY);
    const oldState = parseJson(oldRaw);
    if (oldState && (oldState.employeeId === employeeId || oldState.deviceId === employeeId)) {
      oldState.employeeId = employeeId;
      oldState.deviceId = employeeId;
      oldState.trialUsed = true;
      oldState.createdBy = oldState.createdBy || 'IPAP_v6.9.4_migrated_to_v6.9.5';
      oldState.firstSeenTs = oldState.firstSeenTs || oldState.installTs || Date.now();
      oldState.trialResetCount = oldState.trialResetCount || 0;
      await writeState(employeeId, oldState);
      try { localStorage.removeItem(getOldStorageKey(employeeId)); localStorage.removeItem(LEGACY_KEY); } catch (_) {}
      return oldState;
    }

    if (foundInvalid || localStorage.getItem(getTamperKey(employeeId))) {
      return makeTamperLockedState(employeeId, 'Licence/trial state was edited or damaged');
    }

    return null;
  }

  async function hmacSignature(employeeId, expiryYYMMDD) {
    return hmacRaw(LICENSE_SECRET, employeeId + expiryYYMMDD, 5);
  }

  async function parseKey(key, currentEmployeeId) {
    if (!key || !currentEmployeeId) return null;
    key = String(key).trim().toUpperCase().replace(/\s+/g, '').replace(/-/g, '');
    if (key.length !== 22) return null;

    const prefix = key.slice(0, 3);
    const employeeId = key.slice(3, 11);
    const expiryYYMMDD = key.slice(11, 17);
    const signature = key.slice(17, 22);

    if (prefix !== 'EMP') return null;
    if (!/^\d{8}$/.test(employeeId)) return null;
    if (employeeId !== currentEmployeeId) return null;
    if (!/^\d{6}$/.test(expiryYYMMDD)) return null;
    if (!/^[0-9A-F]{5}$/.test(signature)) return null;

    const expected = await hmacSignature(employeeId, expiryYYMMDD);
    if (signature !== expected) return null;

    const y = 2000 + Number(expiryYYMMDD.slice(0, 2));
    const m = Number(expiryYYMMDD.slice(2, 4));
    const d = Number(expiryYYMMDD.slice(4, 6));
    const expiryDate = new Date(Date.UTC(y, m - 1, d));
    if (expiryDate.getUTCFullYear() !== y || expiryDate.getUTCMonth() !== m - 1 || expiryDate.getUTCDate() !== d) return null;

    const expiryTs = Date.UTC(y, m - 1, d + 1);
    return {
      employeeId,
      expiryStr: `${y}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`,
      expiryYYMMDD,
      signature,
      expiryTs
    };
  }

  async function getOrCreateState() {
    const employeeId = getEmployeeIdFromDom();
    if (!employeeId) return { state: null, employeeId: null };

    let state = await readState(employeeId);
    const now = Date.now();

    if (!state || typeof state !== 'object') {
      state = {
        employeeId,
        deviceId: employeeId,
        installTs: now,
        firstSeenTs: now,
        createdBy: 'IPAP_v6.9.5_EMP_PROTECTED',
        trialUsed: true,
        trialResetCount: 0
      };
      await writeState(employeeId, state);
    }

    state.employeeId = employeeId;
    state.deviceId = employeeId;
    if (!state.installTs) state.installTs = now;
    if (!state.firstSeenTs) state.firstSeenTs = state.installTs;

    await writeState(employeeId, state);
    return { state, employeeId };
  }

  async function buildAuth() {
    const { state, employeeId } = await getOrCreateState();
    const now = Date.now();

    if (!employeeId || !state) {
      return {
        allowed: false,
        mode: 'employee_missing',
        employeeId: null,
        deviceId: null,
        daysLeft: 0,
        expiryStr: null,
        storage: 'Employee ID not found in DOM'
      };
    }

    if (!(await isStateValid(state, employeeId))) {
      const locked = await makeTamperLockedState(employeeId, 'State signature mismatch');
      return {
        allowed: false,
        mode: 'tamper_locked',
        employeeId,
        deviceId: employeeId,
        daysLeft: 0,
        expiryStr: null,
        installTs: locked.installTs,
        storage: 'app.indiapost.gov.in localStorage protected'
      };
    }

    if (state.tamperLocked) {
      return {
        allowed: false,
        mode: 'tamper_locked',
        employeeId,
        deviceId: employeeId,
        daysLeft: 0,
        expiryStr: null,
        installTs: state.installTs,
        storage: 'Trial locked due to local edit'
      };
    }

    // Clock rollback protection: if system date is moved before trial start, lock trial.
    if (now + 5 * 60 * 1000 < Number(state.installTs || 0)) {
      const locked = await makeTamperLockedState(employeeId, 'System clock rollback detected');
      return { allowed: false, mode: 'tamper_locked', employeeId, deviceId: employeeId, daysLeft: 0, expiryStr: null, installTs: locked.installTs, storage: 'Clock rollback lock' };
    }

    if (state.licenseKey && state.licenseEmployeeId === employeeId && state.licenseExpiryTs && now < state.licenseExpiryTs) {
      return {
        allowed: true,
        mode: 'license',
        employeeId,
        deviceId: employeeId,
        licenseKey: state.licenseKey,
        daysLeft: Math.max(0, Math.ceil((state.licenseExpiryTs - now) / DAY)),
        expiryStr: state.licenseExpiryStr,
        installTs: state.installTs,
        storage: 'app.indiapost.gov.in localStorage protected'
      };
    }

    if (state.licenseKey && state.licenseEmployeeId === employeeId && state.licenseExpiryTs && now >= state.licenseExpiryTs) {
      return { allowed: false, mode: 'license_expired', employeeId, deviceId: employeeId, licenseKey: state.licenseKey, daysLeft: 0, expiryStr: state.licenseExpiryStr, installTs: state.installTs, storage: 'app.indiapost.gov.in localStorage protected' };
    }

    const trialMs = TRIAL_DAYS * DAY;
    const remaining = Math.max(0, trialMs - (now - state.installTs));
    const expiryStr = new Date(state.installTs + trialMs).toISOString().slice(0, 10);

    if (remaining > 0) {
      return { allowed: true, mode: 'trial', employeeId, deviceId: employeeId, daysLeft: Math.ceil(remaining / DAY), expiryStr, installTs: state.installTs, storage: 'app.indiapost.gov.in localStorage protected' };
    }

    return { allowed: false, mode: 'trial_expired', employeeId, deviceId: employeeId, daysLeft: 0, expiryStr, installTs: state.installTs, storage: 'app.indiapost.gov.in localStorage protected' };
  }

  async function activateLicense(key) {
    const { state, employeeId } = await getOrCreateState();
    if (!employeeId || !state) {
      return { valid: false, reason: 'Employee ID not found. Open India Post page after login/profile is loaded.' };
    }

    const parsed = await parseKey(key, employeeId);
    if (!parsed) {
      return { valid: false, reason: 'Invalid license key. Expected format: EMP + 8 digit Employee ID + YYMMDD + 5 digit signature.' };
    }
    if (Date.now() > parsed.expiryTs) {
      return { valid: false, reason: 'This license key has already expired.' };
    }

    const normalizedKey = String(key).trim().toUpperCase().replace(/\s+/g, '').replace(/-/g, '');
    state.licenseKey = normalizedKey;
    state.licenseEmployeeId = employeeId;
    state.licenseDeviceId = employeeId;
    state.licenseExpiryStr = parsed.expiryStr;
    state.licenseExpiryTs = parsed.expiryTs;
    state.licenseSavedAt = Date.now();
    state.tamperLocked = false;
    delete state.tamperReason;
    try { localStorage.removeItem(getTamperKey(employeeId)); } catch (_) {}
    await writeState(employeeId, state);

    return {
      valid: true,
      daysLeft: Math.ceil((parsed.expiryTs - Date.now()) / DAY),
      expiryStr: parsed.expiryStr
    };
  }

  function todayYYMMDD(offsetDays) {
    const dt = new Date(Date.now() + (offsetDays || 0) * DAY);
    const yy = String(dt.getFullYear()).slice(-2);
    const mm = String(dt.getMonth() + 1).padStart(2, '0');
    const dd = String(dt.getDate()).padStart(2, '0');
    return yy + mm + dd;
  }

  async function adminSig(employeeId, yymmdd) {
    return hmacRaw(LICENSE_SECRET, employeeId + yymmdd + ADMIN_SALT, 5);
  }

  async function verifyAdminCode(code, employeeId) {
    code = String(code || '').trim().toUpperCase().replace(/\s+/g, '').replace(/-/g, '');
    if (code.length !== 22 || !code.startsWith('RST')) return false;
    const emp = code.slice(3, 11);
    const dt = code.slice(11, 17);
    const sig = code.slice(17, 22);
    if (emp !== employeeId || !/^\d{6}$/.test(dt) || !/^[0-9A-F]{5}$/.test(sig)) return false;
    // Accept today, yesterday, tomorrow to avoid small date/time mismatch.
    for (const off of [-1, 0, 1]) {
      const t = todayYYMMDD(off);
      if (dt === t && sig === await adminSig(employeeId, t)) return true;
    }
    return false;
  }

  async function adminResetTrial(code) {
    const employeeId = getEmployeeIdFromDom();
    if (!employeeId) return { ok: false, reason: 'Employee ID not found in DOM' };
    if (!(await verifyAdminCode(code, employeeId))) return { ok: false, reason: 'Invalid admin reset code' };

    const now = Date.now();
    const state = {
      employeeId,
      deviceId: employeeId,
      installTs: now,
      firstSeenTs: now,
      createdBy: 'IPAP_v6.9.5_admin_code_reset',
      trialUsed: true,
      trialResetCount: 1,
      tamperLocked: false
    };
    for (const k of allStateKeys(employeeId)) { try { localStorage.removeItem(k); } catch (_) {} }
    try { localStorage.removeItem(getTamperKey(employeeId)); } catch (_) {}
    await writeState(employeeId, state);
    return { ok: true, action: 'reset', employeeId };
  }

  // Utility for owner only: paste in console to generate today's reset code for visible Employee ID.
  // window.IPAP_OWNER_MAKE_RESET_CODE()
  window.IPAP_OWNER_MAKE_RESET_CODE = async function () {
    const employeeId = getEmployeeIdFromDom();
    if (!employeeId) return 'Employee ID not found';
    const dt = todayYYMMDD(0);
    return 'RST' + employeeId + dt + await adminSig(employeeId, dt);
  };

  window.addEventListener('IPAP_fromExt', async (e) => {
    const d = e.detail || {};
    if (d.cmd === 'STORE_GET_AUTH') {
      emit({ type: 'STORE_AUTH', nonce: d.nonce, auth: await buildAuth() });
    }
    if (d.cmd === 'STORE_ACTIVATE_LICENSE') {
      emit({ type: 'STORE_LICENSE_RESULT', nonce: d.nonce, result: await activateLicense(d.licenseKey) });
    }
    // Old open reset commands are intentionally blocked in v6.9.5.
    if (d.cmd === 'STORE_FORCE_EXPIRE_TRIAL' || d.cmd === 'STORE_RESET_TRIAL_DEV_ONLY') {
      emit({ type: 'STORE_ADMIN_DONE', nonce: d.nonce, ok: false, reason: 'Admin code required' });
    }
    // Owner reset: requires RST + EmployeeID + YYMMDD + SIG5 code.
    if (d.cmd === 'STORE_ADMIN_RESET_WITH_CODE') {
      emit({ type: 'STORE_ADMIN_DONE', nonce: d.nonce, result: await adminResetTrial(d.adminCode) });
    }
  });

  emit({ type: 'STORE_READY' });
  console.log('[IPAP STORE v6.9.5 EMP] Protected Employee ID monthly license bridge ready');
})();
