// India Post Auto Bag Open Pro v6.9.5 — Offline site-localStorage popup
(async () => {
  'use strict';
  const WEBSITE = 'https://indiapostscanner-dotcom.github.io/indiapost-scanner-pro/';
  let tabId = null;
  let delay = 0;
  let deviceId = null; // compatibility only; licence identity is Employee ID from DOM
  const pending = new Map();

  const $ = id => document.getElementById(id);
  const mainUI = $('main-ui'), expScreen = $('expired-screen'), expDeviceId = $('exp-device-id');
  const licBox = $('lic-box'), licTitle = $('lic-title'), licDetail = $('lic-detail');
  const connDot = $('conn-dot'), connText = $('conn-text');
  const btnStart = $('btn-start'), btnStop = $('btn-stop'), btnReconn = $('btn-reconnect');
  const curScan = $('cur-scan'), curVal = $('cur-val'), prog = $('prog'), sDone = $('s-done'), sFail = $('s-fail'), sLeft = $('s-left'), logEl = $('log');
  const keyInput = $('key-input'), btnKey = $('btn-key'), keyMsg = $('key-msg'), mainKeyRow = $('main-key-row');
  const keyInputExp = $('key-input-exp'), btnKeyExp = $('btn-key-exp'), keyMsgExp = $('key-msg-exp');

  function fnv1a(str) {
    let h = 0x811c9dc5;
    for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 0x01000193) >>> 0; }
    return h.toString(16).toUpperCase().padStart(8, '0');
  }

  // ── FIXED makeDeviceId: uses canvas fingerprint ─────────────────────
  // Canvas rendering is unique per GPU + graphics driver combination.
  // Even identical hardware running same Chrome version renders
  // canvas text/gradients differently due to GPU driver differences.
  // This ensures each physical PC gets a different Device ID.
  // Previous version used only userAgent/timezone/screen which are
  // IDENTICAL across all India Post office PCs → same deviceId → bug.
  function getCanvasFingerprint() {
    try {
      const c = document.createElement('canvas');
      c.width = 200; c.height = 50;
      const ctx = c.getContext('2d');
      // Text rendering varies per GPU/driver
      ctx.textBaseline = 'top';
      ctx.font = '14px Arial';
      ctx.fillStyle = '#c62828';
      ctx.fillText('IndiaPost2025' + navigator.language, 2, 2);
      ctx.fillStyle = 'rgba(79,195,247,0.8)';
      ctx.font = '11px Courier New';
      ctx.fillText(screen.width + 'x' + screen.height, 4, 20);
      // Gradient rendering also varies per GPU
      const g = ctx.createLinearGradient(0, 0, 200, 0);
      g.addColorStop(0, '#e8472a'); g.addColorStop(1, '#4fc3f7');
      ctx.fillStyle = g;
      ctx.fillRect(0, 35, 200, 10);
      return c.toDataURL();
    } catch (_) { return 'no-canvas'; }
  }

  function makeDeviceId() {
    const canvas  = getCanvasFingerprint();
    const stable  = [
      navigator.language || '',
      Intl.DateTimeFormat().resolvedOptions().timeZone || '',
      String(navigator.hardwareConcurrency || 0),
      String(screen.width),
      String(screen.height),
      String(screen.colorDepth || 0),
      String(navigator.deviceMemory || 0)
    ].join('|');
    // Combine canvas (GPU-unique) with stable properties
    // fnv1a of canvas alone gives 8 unique hex chars
    const h1 = fnv1a(canvas);
    const h2 = fnv1a(stable);
    // XOR mix to get 8 chars that depend on BOTH
    const mixed = (parseInt(h1, 16) ^ parseInt(h2, 16))
      .toString(16).toUpperCase().padStart(8, '0');
    return 'RMS' + mixed;
  }
  function log(msg, cls) {
    if (!logEl) return;
    const d = document.createElement('div');
    const t = new Date().toLocaleTimeString('en-IN', { hour12: false });
    if (cls) d.className = cls;
    d.textContent = t + ' ' + msg;
    logEl.insertBefore(d, logEl.firstChild);
    while (logEl.children.length > 120) logEl.removeChild(logEl.lastChild);
  }
  function setConn(state, text) { connDot.className = 'conn-dot ' + state; connText.textContent = text; }
  function setProgress(done, total) { prog.style.width = total > 0 ? Math.round((done / total) * 100) + '%' : '0%'; }
  function updateCal(msg) {
    const map = { hasOnChange:'ci-change', hasOnKeyDown:'ci-keydown', hasOnKeyPress:'ci-keypress', hasAddBtn:'ci-addbtn', hasOnClick:'ci-onclick' };
    for (const [key,id] of Object.entries(map)) {
      const el = $(id); if (!el) continue;
      const val = msg[key];
      if (typeof val === 'boolean') { el.textContent = val ? '✓' : '✗'; el.className = 'ci-val ' + (val ? 'ci-yes' : 'ci-no'); }
    }
    if (typeof msg.barcodes === 'number') sLeft.textContent = msg.barcodes;
  }
  function toBg(msg) {
    return new Promise(resolve => chrome.runtime.sendMessage(msg, resp => {
      if (chrome.runtime.lastError) resolve(null); else resolve(resp);
    }));
  }
  async function sendCmd(cmd, extra = {}) { return toBg({ type:'CMD', tabId, cmd, ...extra }); }
  function storeCmd(cmd, extra = {}, timeout = 2500) {
    const nonce = Date.now() + '-' + Math.random().toString(36).slice(2);
    return new Promise(async resolve => {
      const timer = setTimeout(() => { pending.delete(nonce); resolve(null); }, timeout);
      pending.set(nonce, payload => { clearTimeout(timer); resolve(payload); });
      await sendCmd(cmd, { nonce, ...extra });
    });
  }

  function showActive(auth) {
    expScreen.classList.remove('show');
    mainUI.classList.add('show');
    if (auth.mode === 'trial') {
      licBox.className = 'lic-box trial';
      licTitle.textContent = `🎁 ${auth.daysLeft}-Day Trial Active`;
      licDetail.innerHTML = `Remaining: <span class="hl">${auth.daysLeft} day${auth.daysLeft===1?'':'s'}</span> · Trial ends: ${auth.expiryStr || '—'}<br>Employee ID: <span class="did">${auth.employeeId || auth.deviceId || '—'}</span><br>Storage: ${auth.storage || 'site localStorage'}`;
      mainKeyRow.style.display = 'none'; keyMsg.style.display = 'none'; btnKey.style.display = 'none';
    } else {
      licBox.className = 'lic-box license';
      licTitle.textContent = '✅ License Active';
      licDetail.innerHTML = `Expires: <span class="ok">${auth.expiryStr || '—'}</span> · <span class="ok">${auth.daysLeft} day${auth.daysLeft===1?'':'s'} left</span><br>Employee ID: <span class="did">${auth.employeeId || auth.deviceId || '—'}</span><br>License Key: <span class="did">${auth.licenseKey || 'Saved'}</span><br>Works offline after activation.`;
      mainKeyRow.style.display = 'none'; keyMsg.style.display = 'none'; btnKey.style.display = 'none';
    }
  }
  function showExpired(auth) {
    mainUI.classList.remove('show');
    expScreen.classList.add('show');
    expDeviceId.textContent = auth.licenseKey || auth.employeeId || auth.deviceId || '—';
  }
  async function refreshAuth() {
    const res = await storeCmd('STORE_GET_AUTH', { deviceId });
    const auth = res?.auth;
    if (!auth) {
      mainUI.classList.add('show');
      licBox.className = 'lic-box expired'; licTitle.textContent = 'Storage Error';
      licDetail.innerHTML = 'Could not access app.indiapost.gov.in localStorage. Keep India Post page open and reconnect.';
      return null;
    }
    if (auth.allowed) showActive(auth); else showExpired(auth);
    return auth;
  }
  async function submitKey(value, msgEl) {
    const key = (value || '').trim().toUpperCase();
    msgEl.textContent = 'Validating offline…'; msgEl.className = 'key-msg lw';
    const res = await storeCmd('STORE_ACTIVATE_LICENSE', { deviceId, licenseKey: key });
    const r = res?.result;
    if (r?.valid) { msgEl.textContent = '✓ Activated. Reloading…'; msgEl.className = 'key-msg ok'; setTimeout(() => location.reload(), 900); }
    else { msgEl.textContent = '✗ ' + (r?.reason || 'Invalid key'); msgEl.className = 'key-msg err'; }
  }
  btnKey.addEventListener('click', () => submitKey(keyInput.value, keyMsg));
  keyInput.addEventListener('keydown', e => { if (e.key === 'Enter') submitKey(keyInput.value, keyMsg); });
  btnKeyExp.addEventListener('click', () => submitKey(keyInputExp.value, keyMsgExp));
  keyInputExp.addEventListener('keydown', e => { if (e.key === 'Enter') submitKey(keyInputExp.value, keyMsgExp); });

  chrome.runtime.onMessage.addListener(msg => {
    if (msg.__src !== 'bg') return;
    if ((msg.type === 'STORE_AUTH' || msg.type === 'STORE_LICENSE_RESULT' || msg.type === 'STORE_ADMIN_DONE') && pending.has(msg.nonce)) {
      pending.get(msg.nonce)(msg); pending.delete(msg.nonce); return;
    }
    const { type } = msg;
    if (type === 'PAGE_READY' || type === 'PONG') { setConn('ok', `Connected ✓ (${msg.barcodes ?? 0} articles)`); btnStart.disabled = false; updateCal(msg); log(`Connected. ${msg.barcodes ?? 0} expected article(s) found.`, 'lg'); }
    if (type === 'CALIBRATION') updateCal(msg);
    if (type === 'STARTED') { btnStart.disabled = true; btnStop.disabled = false; prog.classList.add('pulse'); sLeft.textContent = msg.total ?? '…'; setProgress(0, msg.total || 1); log(`▶ Scan started — ${msg.total} article(s).`, 'lg'); }
    if (type === 'SCANNING') { curScan.classList.add('show'); curVal.textContent = msg.barcode; sDone.textContent = msg.done; sFail.textContent = msg.failed; sLeft.textContent = msg.remaining ?? '…'; }
    if (type === 'SCANNED') { sDone.textContent = msg.done; sFail.textContent = msg.failed; const total = parseInt(sDone.textContent) + parseInt(sFail.textContent) + parseInt(sLeft.textContent || 0); setProgress(msg.done, total); log(msg.msg || '✓ ' + msg.barcode, msg.cls || 'lg'); }
    if (type === 'FAILED') { sDone.textContent = msg.done; sFail.textContent = msg.failed; log(msg.msg || '✗ ' + msg.barcode, 'lr'); }
    if (type === 'LOG') log(msg.msg, msg.cls);
    if (type === 'DONE') { prog.classList.remove('pulse'); prog.style.width = '100%'; btnStart.disabled = false; btnStop.disabled = true; curScan.classList.remove('show'); sLeft.textContent = '0'; setConn('ok', `Done ✓ Scanned: ${msg.done} Failed: ${msg.failed}`); log(`✓ Complete! Scanned: ${msg.done} Failed: ${msg.failed}`, 'lg'); }
    if (type === 'STOPPED') { prog.classList.remove('pulse'); btnStart.disabled = false; btnStop.disabled = true; curScan.classList.remove('show'); setConn('ok', 'Stopped'); log(`⏹ Stopped. Scanned: ${msg.done} Failed: ${msg.failed}`, 'lw'); }
  });

  document.querySelectorAll('.spd').forEach(btn => btn.addEventListener('click', () => { document.querySelectorAll('.spd').forEach(b => b.classList.remove('on')); btn.classList.add('on'); delay = parseInt(btn.dataset.ms, 10); log('Speed: ' + (delay || 'Max') + (delay ? 'ms' : '')); }));
  btnStart.addEventListener('click', async () => { sDone.textContent='0'; sFail.textContent='0'; prog.style.width='0%'; await sendCmd('CALIBRATE'); await new Promise(r=>setTimeout(r,200)); await sendCmd('START', { delay }); });
  btnStop.addEventListener('click', () => sendCmd('STOP'));
  btnReconn.addEventListener('click', async () => { btnStart.disabled = true; await connectAndAuth(); });

  async function connectAndAuth() {
    setConn('busy', 'Injecting scripts…'); log('Connecting to page…', 'lw');
    const inj = await toBg({ type:'INJECT', tabId });
    if (!inj?.ok) { setConn('err', 'Injection failed'); log('Error: ' + (inj?.error || 'unknown'), 'lr'); return; }
    await new Promise(r => setTimeout(r, 300));
    await refreshAuth();
    await new Promise(r => setTimeout(r, 250));
    await sendCmd('PING');
  }

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) return;
  tabId = tab.id; deviceId = makeDeviceId();
  if (!tab.url?.includes('app.indiapost.gov.in')) {
    mainUI.classList.add('show'); licBox.className='lic-box expired'; licTitle.textContent='Open India Post Page'; licDetail.innerHTML='Please open app.indiapost.gov.in Bag Open page first.'; setConn('err','Wrong page'); return;
  }
  log('Tab: ' + (tab.title || tab.url).slice(0,45));
  await connectAndAuth();
})();
