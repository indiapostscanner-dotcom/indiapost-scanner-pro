// ============================================================
// India Post Auto Bag Open Pro — PAGE WORLD v4.0
//
// BUILT FROM REAL DIAGNOSTIC DATA — not guesswork.
//
// What the real USB scanner does (from diagnostic JSON):
// 1. keydown(char) → keypress(char) → input(insertText) → keyup — per char
// 2. Final: keydown(Enter) → keypress(Enter) → CHANGE EVENT → DOM updates
//    → keyup(Enter) [input value is already "" by keyup]
//
// Key facts:
// - ZERO fetch / XHR / WebSocket — pure internal React state, no network
// - Page submits on keydown(Enter) + change — NOT on keyup
// - DOM updates 11ms after Enter keydown (extremely fast local state)
// - Scanned table class: "sc-dprtRQ htmdXE rdt_TableBody"  
// - Success signal: rdt_TableBody div added containing the barcode
// - Input clears itself on keyup Enter (React controlled input)
// ============================================================

(function () {
  if (window.__IPAP_v52) return;
  window.__IPAP_v52 = true;

  // Web Worker sleep — not throttled in background tabs.
  // Chrome throttles normal setTimeout to 1s when tab is hidden.
  // Web Workers run at full speed regardless of tab visibility.
  const _wb = new Blob([
    'self.onmessage=function(e){' +
    '  if(e.data<=0){self.postMessage(0);return;}' +
    '  setTimeout(function(){self.postMessage(0);},e.data);' +
    '};'
  ], { type: 'application/javascript' });
  const _wu = URL.createObjectURL(_wb);
  function sleep(ms) {
    if (ms <= 0) return Promise.resolve();
    return new Promise(resolve => {
      const w = new Worker(_wu);
      w.onmessage = () => { w.terminate(); resolve(); };
      w.postMessage(ms);
    });
  }

  function emit(detail) {
    window.dispatchEvent(new CustomEvent('IPAP_toExt', { detail }));
  }
  function log(msg, cls) { emit({ type: 'LOG', msg, cls: cls || '' }); }

  // ── Native setter — MUST use this to update React controlled input ──
  const nativeSetter = Object.getOwnPropertyDescriptor(
    HTMLInputElement.prototype, 'value'
  )?.set;

  function setNativeValue(input, val) {
    if (nativeSetter) nativeSetter.call(input, val);
    else input.value = val;
  }

  // ── Already-scanned guard ────────────────────────────────
  const scannedSet = new Set();

  // ============================================================
  //  DOM HELPERS
  // ============================================================

  function getInput() {
    return (
      document.getElementById('ArtNo') ||
      document.querySelector('input[name="ArtNo"]') ||
      document.querySelector('input[minlength="13"][maxlength="13"]') ||
      Array.from(document.querySelectorAll('input')).find(i =>
        /scan.?article|article.?no/i.test(i.placeholder + i.id + i.name)
      )
    );
  }

  function getAddButton() {
    return Array.from(document.querySelectorAll('button')).find(b =>
      /^add/i.test(b.textContent?.trim()) && !b.disabled
    ) || null;
  }

  // ============================================================
  //  TABLE READING — using exact class names from diagnostic
  //
  //  Scanned table body class: "sc-dprtRQ htmdXE rdt_TableBody"
  //  Expected table: the OTHER rdt_TableBody on the page
  //  We identify them by position — Scanned is LEFT, Expected RIGHT
  // ============================================================

  const BARCODE_RE = /^[A-Z]{2}\d{9}[A-Z]{2}$/;

  function getAllTableBodies() {
    // Use exact class from diagnostic — rdt_TableBody is the key class
    return Array.from(document.querySelectorAll('.rdt_TableBody'));
  }

  function getExpectedTableBody() {
    const bodies = getAllTableBodies();
    if (bodies.length === 0) return null;
    if (bodies.length === 1) return bodies[0];

    // Two tables: identify Expected by its heading
    // Walk up from each body to find the nearest heading text
    for (const body of bodies) {
      let el = body.parentElement;
      for (let i = 0; i < 10; i++) {
        if (!el) break;
        const heading = el.querySelector('h2,h3,h4,h5,div[class*="header"],div[class*="Header"]');
        if (heading && /expected/i.test(heading.textContent)) return body;
        el = el.parentElement;
      }
    }

    // Fallback: Expected table is always on the RIGHT = later in DOM
    return bodies[bodies.length - 1];
  }

  function getScannedTableBody() {
    const bodies = getAllTableBodies();
    if (bodies.length === 0) return null;
    if (bodies.length === 1) return null; // only expected table visible

    // Scanned is always on the LEFT = earlier in DOM
    return bodies[0];
  }

  // Read barcodes ONLY from Expected table, filtered by scannedSet
  function getExpectedBarcodes() {
    const body = getExpectedTableBody();
    if (!body) return [];
    const found = new Set();
    body.querySelectorAll('[id^="cell-2-"], [role="cell"], td').forEach(el => {
      const t = el.innerText?.trim().toUpperCase();
      if (BARCODE_RE.test(t) && !scannedSet.has(t)) found.add(t);
    });
    return [...found];
  }

  function getExpectedCount() { return getExpectedBarcodes().length; }
  function getFirstBarcode()  { return getExpectedBarcodes()[0] || null; }
  function isAllDone()        { return getExpectedCount() === 0; }

  // ============================================================
  //  REACT PROPS — direct access, no fiber walking needed
  //  The diagnostic showed the input responds to keydown+change.
  //  We use __reactProps for the most direct path.
  // ============================================================

  function getReactProps(el) {
    const k = Object.keys(el).find(k => k.startsWith('__reactProps'));
    return k ? el[k] : null;
  }

  // ============================================================
  //  CORE TRIGGER — exactly mirrors real scanner sequence
  //
  //  Real scanner sequence from diagnostic:
  //  keydown(ch) → keypress(ch) → input(insertText) → keyup(ch)
  //  ...repeat per char...
  //  keydown(Enter) → keypress(Enter) → change → [DOM updates] → keyup(Enter)
  //
  //  Timing from diagnostic:
  //  - All chars arrive within ~35ms (scanner fires at ~2ms per char)
  //  - Enter arrives immediately after last char
  //  - DOM updates 11ms after Enter keydown
  //  - Input clears on keyup Enter
  // ============================================================

  function fireKey(target, type, key, keyCode, extra) {
    target.dispatchEvent(new KeyboardEvent(type, {
      key, code: extra?.code || key,
      keyCode, which: keyCode,
      charCode: type === 'keypress' ? keyCode : 0,
      bubbles: true, cancelable: true, composed: true,
      shiftKey: extra?.shift || false,
      repeat: false, location: 0,
      ctrlKey: false, altKey: false, metaKey: false,
    }));
  }

  async function triggerScan(barcode) {
    const input = getInput();
    if (!input) return { ok: false, reason: 'no_input' };
    if (scannedSet.has(barcode)) return { ok: false, reason: 'already_scanned' };

    // ── Step 1: Focus (scanner always types into focused element) ──
    input.focus();
    await sleep(5);

    // ── Step 2: Clear input via native setter ───────────────────
    setNativeValue(input, '');
    // Fire a backspace input event to clear React state
    input.dispatchEvent(new InputEvent('input', {
      bubbles: true, cancelable: true, composed: true,
      inputType: 'deleteContentBackward'
    }));
    await sleep(3);

    // ── Step 3: Type each character exactly like real scanner ───
    // Scanner fires: keydown → keypress → input(insertText) → keyup
    // Uppercase chars get Shift+key (E, O, I, N etc.)
    for (const ch of barcode) {
      const code = ch.charCodeAt(0);
      const isUpper = ch >= 'A' && ch <= 'Z';
      const isDigit = ch >= '0' && ch <= '9';

      const keyCode = isDigit ? code : ch.toUpperCase().charCodeAt(0);
      const codeStr = isDigit ? 'Digit' + ch : 'Key' + ch.toUpperCase();

      // Shift down for uppercase letters (matches real scanner behaviour)
      if (isUpper) {
        input.dispatchEvent(new KeyboardEvent('keydown', {
          key: 'Shift', code: 'ShiftLeft', keyCode: 16, which: 16,
          bubbles: true, cancelable: true, composed: true,
          shiftKey: true
        }));
      }

      fireKey(input, 'keydown',  ch, keyCode, { code: codeStr, shift: isUpper });
      fireKey(input, 'keypress', ch, keyCode, { code: codeStr, shift: isUpper });

      // Update value via native setter — React reads this on input event
      const newVal = input.value + ch;
      setNativeValue(input, newVal);

      input.dispatchEvent(new InputEvent('input', {
        bubbles: true, cancelable: true, composed: true,
        data: ch, inputType: 'insertText'
      }));

      if (isUpper) {
        input.dispatchEvent(new KeyboardEvent('keyup', {
          key: 'Shift', code: 'ShiftLeft', keyCode: 16, which: 16,
          bubbles: true, cancelable: true, composed: true,
          shiftKey: false
        }));
      }

      fireKey(input, 'keyup', ch.toLowerCase(), keyCode, { code: codeStr });
      // no inter-char sleep — scanner fires chars instantly
    }

    await sleep(2);

    // ── Step 4: Fire Enter — EXACT sequence from diagnostic ─────
    // Real scanner: keydown(Enter) → keypress(Enter) → change → DOM update
    // The change event fires BEFORE keyup — this is what triggers the scan

    fireKey(input, 'keydown',  'Enter', 13, { code: 'Enter' });
    fireKey(input, 'keypress', 'Enter', 13, { code: 'Enter' });

    // Fire change event — this is what the page reacts to for submission
    input.dispatchEvent(new Event('change', {
      bubbles: true, cancelable: true, composed: true
    }));

    // Also call React's onChange directly to ensure state sync
    const props = getReactProps(input);
    if (props?.onChange) {
      props.onChange({
        target: input, currentTarget: input,
        type: 'change',
        nativeEvent: new Event('change'),
        isTrusted: true, bubbles: true,
        defaultPrevented: false,
        preventDefault() {}, stopPropagation() {}, persist() {},
        isDefaultPrevented() { return false; },
        isPropagationStopped() { return false; },
      });
    }

    // ── Step 5: Wait for DOM update (diagnostic shows 11ms) ─────
    await sleep(12);

    // Fire keyup Enter — input clears itself here in real scanner
    fireKey(input, 'keyup', 'Enter', 13, { code: 'Enter' });

    // ── Step 6: Verify success ───────────────────────────────────
    // Success = barcode gone from Expected table within 2 seconds
    const success = await waitForBarcodeGone(barcode, 600);
    if (success) return { ok: true, method: 'exact_scanner_replay' };

    // ── Fallback: if keydown+change didn't work, try Add button ──
    log('→ Fallback: Add button click', 'lw');
    const addBtn = getAddButton();
    if (addBtn) {
      // Re-type the barcode first (input may have cleared)
      if (input.value !== barcode) {
        setNativeValue(input, barcode);
        input.dispatchEvent(new InputEvent('input', {
          bubbles: true, cancelable: true, composed: true,
          data: barcode, inputType: 'insertText'
        }));
        input.dispatchEvent(new Event('change', { bubbles: true }));
        if (props?.onChange) {
          props.onChange({ target: input, currentTarget: input, type: 'change',
            nativeEvent: new Event('change'), isTrusted: true, bubbles: true,
            preventDefault(){}, stopPropagation(){}, persist(){},
            isDefaultPrevented(){ return false; }, isPropagationStopped(){ return false; } });
        }
        await sleep(30);
      }
      const btnProps = getReactProps(addBtn);
      if (btnProps?.onClick) {
        btnProps.onClick({
          type: 'click', target: addBtn, currentTarget: addBtn,
          nativeEvent: new MouseEvent('click', { bubbles: true }),
          isTrusted: true, bubbles: true, button: 0, buttons: 1,
          defaultPrevented: false,
          preventDefault(){ this.defaultPrevented = true; },
          stopPropagation(){}, persist(){},
          isDefaultPrevented(){ return this.defaultPrevented; },
          isPropagationStopped(){ return false; }
        });
      } else {
        addBtn.click();
      }
      const success2 = await waitForBarcodeGone(barcode, 600);
      if (success2) return { ok: true, method: 'add_button_fallback' };
    }

    return { ok: false, reason: 'all_methods_failed' };
  }

  // ============================================================
  //  SUCCESS VERIFICATION
  //  Primary: barcode disappears from Expected table
  //  Backed by scannedSet — prevents re-scan regardless
  // ============================================================

  async function waitForBarcodeGone(barcode, timeoutMs) {
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      await sleep(8);
      if (!getExpectedBarcodes().includes(barcode)) return true;
    }
    return false;
  }

  // ============================================================
  //  CALIBRATION
  // ============================================================

  function calibrate() {
    const input   = getInput();
    const addBtn  = getAddButton();
    const props   = input ? getReactProps(input) : null;
    const btnProps = addBtn ? getReactProps(addBtn) : null;
    const bodies  = getAllTableBodies();
    return {
      ready:          !!input,
      hasInput:       !!input,
      hasAddBtn:      !!addBtn,
      hasOnChange:    !!props?.onChange,
      hasOnKeyDown:   !!props?.onKeyDown,
      hasOnKeyPress:  !!props?.onKeyPress,
      hasOnClick:     !!btnProps?.onClick,
      tableCount:     bodies.length,
      barcodes:       getExpectedCount(),
      scanned:        scannedSet.size,
    };
  }

  // ============================================================
  //  MAIN SCAN LOOP
  // ============================================================
  let running = false, stopFlag = false;

  async function scanAll(delay) {
    if (running) return;
    running = true; stopFlag = false;

    const cal = calibrate();
    emit({ type: 'STARTED', total: cal.barcodes });
    log('▶ ' + cal.barcodes + ' articles | tables=' + cal.tableCount +
        ' | onChange=' + cal.hasOnChange +
        ' | onKeyDown=' + cal.hasOnKeyDown, 'lg');

    let done = 0, failed = 0;

    while (!stopFlag) {
      if (isAllDone()) {
        // Expected column is genuinely empty — all articles processed.
        // This triggers ONLY when getExpectedCount() === 0, meaning
        // every article (including all that slid in during scanning)
        // has been moved to the Scanned side. NOT the initial 10.
        log('✓ Expected column empty — all articles done!', 'lg');
        stopFlag = true; // signal loop to end
        break;
      }

      const barcode = getFirstBarcode();
      if (!barcode) {
        await sleep(150);
        if (!getFirstBarcode()) { log('No more barcodes.', 'lw'); break; }
        continue;
      }

      if (scannedSet.has(barcode)) {
        log('⚠ Skip (already scanned): ' + barcode, 'lw');
        await sleep(50);
        continue;
      }

      emit({ type: 'SCANNING', barcode, done, failed, remaining: getExpectedCount() });
      log('→ Scanning: ' + barcode);

      const result = await triggerScan(barcode);

      if (result.ok) {
        scannedSet.add(barcode); // guard against re-scan
        done++;
        await sleep(15);
        emit({ type: 'SCANNED', barcode, done, failed,
               msg: '✓ ' + barcode + ' [' + result.method + ']', cls: 'lg' });
      } else {
        failed++;
        emit({ type: 'FAILED', barcode, done, failed,
               msg: '✗ ' + barcode + ' — ' + result.reason, cls: 'lr' });
        await sleep(100);
      }

      if (!stopFlag && !isAllDone()) await sleep(delay);
    }

    running = false;
    emit({ type: stopFlag ? 'STOPPED' : 'DONE', done, failed });
  }

  // ============================================================
  //  COMMAND LISTENER
  // ============================================================
  window.addEventListener('IPAP_fromExt', e => {
    const { cmd, delay } = e.detail || {};
    if (cmd === 'PING' || cmd === 'CALIBRATE') {
      const cal = calibrate();
      emit({ type: cmd === 'PING' ? 'PONG' : 'CALIBRATION', ...cal });
      if (cmd === 'CALIBRATE') {
        log('tables=' + cal.tableCount + ' | onChange=' + cal.hasOnChange +
            ' | onKeyDown=' + cal.hasOnKeyDown + ' | onClick=' + cal.hasOnClick, 'lw');
      }
    }
    if (cmd === 'START') scanAll(delay || 80);
    if (cmd === 'STOP')  { stopFlag = true; log('⏹ Stopped.', 'lw'); }
  });

  // Signal ready
  const cal = calibrate();
  emit({ type: 'PAGE_READY', ...cal });
  console.log(
    '%c[IPAP v4] Ready | tables=' + cal.tableCount +
    ' | onChange=' + cal.hasOnChange +
    ' | articles=' + cal.barcodes,
    'color:#3fb950;font-weight:bold;font-size:14px'
  );
})();
